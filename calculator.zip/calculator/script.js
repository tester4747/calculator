/ Get the display and buttons elements/
const display = document.getElementById("display");
const buttons = document.getElementById("buttons");

// Add a click event listener to the buttons element
buttons.addEventListener("click", function(event) {
  // Get the value of the clicked button
  const value = event.target.getAttribute("data-value");

  // If the clicked button was the "C" sign, clear the display
  if (value === "C") {
    display.value = "";
  }
  // If the clicked button was the "CE" sign, clear the last character from the display
  else if (value === "CE") {
    display.value = display.value.slice(0, -1);
  }
  // If the clicked button was the "back" sign, clear the last character from the display
  else if (value === "back") {
    display.value = display.value.slice(0, -1);
  }
  // If the clicked button was a number, append it to the display
  else if (!isNaN(value)) {
    display.value += value;
  }
  // If the clicked button was an operator, append it to the display
  else if (["+", "-", "*", "/", "^"].includes(value)) {
    display.value += " " + value + " ";
  }
  // If the clicked button was the "=" sign, evaluate the expression and display the result
  else if (value === "=") {
    try {
      display.value = eval(display.value);
    } catch (error) {
      display.value = "Error";
    }
  }
  // If the clicked button was the "+/-" sign, change the sign of the number
  else if (value === "+/-") {
    display.value = -display.value;
  }
  // If the clicked button was the "sqrt" sign, calculate the square root of the number
  else if (value === "sqrt") {
    display.value = Math.sqrt(display.value);
  }
  // If the clicked button was the "%" sign, calculate the percentage of the number
  else if (value === "%") {
    display.value /= 100;
  }
  // If the clicked button was the "ln" sign, calculate the natural logarithm of the number
  else if (value === "ln") {
    display.value = Math.log(display.value);
  }
  // If the clicked button was the "log" sign, calculate the logarithm with base 10 of the number
  else if (value === "log") {
    display.value = Math.log10(display.value);
  }
  // If the clicked button was the "sin" sign, calculate the sine of the number
  else if (value === "sin") {
    display.value = Math.sin(display.value);
  }
  // If the clicked button was the "cos" sign, calculate the cosine of the number
  else if (value === "cos") {
    display.value = Math.cos(display.value);
  }
  // If the clicked button was the "tan
  // If the clicked button was the "tan" sign, calculate the tangent of the number
  else if (value === "tan") {
    display.value = Math.tan(display.value);
  }
  // If the clicked button was the "!" sign, calculate the factorial of the number
  else if (value === "!") {
    let result = 1;
    for (let i = display.value; i > 0; i--) {
      result *= i;
    }
    display.value = result;
  }
});
